Copy the supplied VADER lexicon folder here (nltk_data/sentiment/vader_lexicon.zip).
