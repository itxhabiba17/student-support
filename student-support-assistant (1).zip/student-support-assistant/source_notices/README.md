Copy the supplied source_notices/ files here and keep them with the data.
