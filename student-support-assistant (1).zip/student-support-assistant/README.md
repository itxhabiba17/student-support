# 🎓 Student Support and Course Feedback Assistant

**AI for Everyone – Project 01.** An educational Streamlit prototype for a teacher reviewing a class
after the second assessment period. It brings marks and course feedback together in **five tabs**:

| Tab | What it does | Model / tool |
|---|---|---|
| 1. Class overview & support prediction | 3 charts, test metrics, record form with validation, support flag | scikit-learn Decision Tree (+ baseline) |
| 2. Learning profiles | group sizes/averages in original units, coloured scatter | StandardScaler + KMeans (3 groups) |
| 3. Feedback digit | sample or uploaded digit → prediction → teacher confirms | small Keras CNN (3 epochs) |
| 4. Course comments | sentiment + keyword topics, metrics vs reference labels | NLTK VADER + `topic_keywords.json` |
| 5. Teaching summary | **Offline summary (default)**, optional Groq summary, prompt comparison | Groq Free Plan (`openai/gpt-oss-20b`) |

> Decision support only. The support flag is a classroom modelling target (`needs_support = 1` when G3 < 10),
> not a decision about promotion, admission or a real student. A teacher reviews every suggestion.

**Live demo:** _add your Streamlit Community Cloud link here_

## Results (Colab run, fixed splits, test set evaluated once)

| Component | Metric | Result |
|---|---|---|
| Decision tree (max_depth=4) | test accuracy / macro F1 | **0.917 / 0.907** |
| Majority baseline | test accuracy / macro F1 | 0.667 / 0.400 |
| Decision tree | class 1 precision / recall | 0.857 / 0.900 (test: 40 × class 0, 20 × class 1) |
| KMeans (3 groups, train) | group sizes | 25 / 144 / 107 (silhouette k=3: 0.321, k=2: 0.304) |
| Small CNN (3 epochs) | test accuracy / macro F1 | **0.926 / 0.925** |
| VADER vs reference labels | accuracy / macro F1 | **0.967 / 0.967** (1 disagreement: mixed comment) |

Training versions: scikit-learn 1.6.1 · TensorFlow 2.21.0 · pandas 2.2.3 (pinned in `requirements.txt`).

---

## Repository layout
```
├── app.py                     # Streamlit app (5 tabs) – loads saved models, never retrains
├── train_all.py               # trains all models once -> models/, reports/
├── prepare_repo.py            # copies pack + Colab downloads into the repo, checks files
├── requirements.txt           # runtime deps (Streamlit Cloud)
├── requirements-dev.txt       # + pytest
├── src/
│   ├── config.py              # paths, Groq model id, ranges, units
│   ├── data_loader.py         # reads the supplied files as-is
│   ├── validation.py          # range / category / missing checks BEFORE predict
│   ├── tabular.py             # decision tree + DummyClassifier baseline
│   ├── clustering.py          # KMeans (3 groups) + descriptions
│   ├── image_model.py         # CNN + image preprocessing
│   ├── nlp.py                 # VADER + topic rules
│   └── llm.py                 # offline template + Groq call with failure handling
├── data/                      # COPY the supplied Project_01 data files here
├── sample_images/             # COPY the supplied sample digit images here
├── models/                    # supervised.joblib, clusters.joblib, images.keras, *.json
├── reports/                   # charts and metrics written by train_all.py
├── nltk_data/                 # COPY the supplied VADER lexicon here (offline)
├── source_notices/            # COPY the supplied attribution files here
├── notebooks/                 # Colab training notebook
├── tests/test_basic.py
└── .streamlit/  config.toml, secrets.toml.example
```

## 1. Put the data and trained models in the repo (one command)
You need three things on your computer:
- the extracted **`Project_01`** folder from the dataset pack,
- **`models_and_reports.zip`** and **`reports.zip`** downloaded by the last notebook cell.

```bash
python prepare_repo.py --pack "path/to/Project_01" --models models_and_reports.zip --reports reports.zip
```
It copies `data/` (without `images.npz`), `sample_images/`, `nltk_data/`, `source_notices/`,
`models/` and `reports/`, then prints a checklist. All lines should say **OK**.

Manual alternative: copy those folders yourself so the repo looks like the layout above.

## 2. (Re)train – only if you change something
Training is done in `notebooks/Project_01_Student_Support_Colab.ipynb` (Colab). Locally you can also run
`python train_all.py` (needs `data/images.npz`). The app itself never trains.

## 3. Run the app
```bash
streamlit run app.py
```

## 4. Optional Groq key
Copy `.streamlit/secrets.toml.example` → `.streamlit/secrets.toml` and add your **free** Groq key
(or `export GROQ_API_KEY=...`). Without a key everything works in **Offline summary** mode.
Missing key, rate limit, timeout, network error and empty output are all caught – the app stays usable.

## 5. Put it on GitHub (browser only, GitHub Free)
1. github.com → **New repository** → name e.g. `student-support-assistant` → Public → Create.
2. **Add file → Upload files** → drag in everything from this folder **except** `data/images.npz`
   and any `secrets.toml` → **Commit changes**.
   (Hidden folders such as `.streamlit/` may need to be uploaded separately – or use the command line below.)

Command line alternative:
```bash
git init && git add . && git commit -m "Student Support Assistant"
git branch -M main
git remote add origin https://github.com/<your-username>/student-support-assistant.git
git push -u origin main
```

## 6. Deploy on Streamlit Community Cloud (free)
1. share.streamlit.io → sign in with GitHub → **Create app**.
2. Pick the repo, branch `main`, main file `app.py`. In *Advanced settings* choose **Python 3.12**.
3. *(Optional)* **Secrets** → paste `GROQ_API_KEY = "..."`.
4. Deploy and paste the link at the top of this README.

GitHub Pages cannot run Streamlit (it only serves static files). If a free limit blocks the live demo,
run it locally and submit a screen recording.

## 7. Tests
```bash
pip install -r requirements-dev.txt
pytest -q
```

| Acceptance check (proposal §9) | How it is handled |
|---|---|
| Open the app without a Groq key | Offline summary is the default; all tabs work |
| Select a supplied example record | Tab 1 dropdown from `example_inputs.csv`, output with meaning |
| Use a supplied sample image | Tab 3, resized to 28×28×1, saved class order |
| Submit a blank comment | Treated as **empty**, excluded from sentiment totals |
| Invalid value / missing column | Clear message, nothing sent to the model (e.g. **G2 = 25 → rejected, range 0–20**) |
| API rate limit / network error | Caught, warning shown, Offline summary offered |
| Restart app / rerun widget | Models cached with `st.cache_resource`; no training in the app |

## Limits
Small dataset (395 records); associations, not causes; MNIST digits do not prove reliability on real
handwriting and must never assign marks; VADER can misread negation, sarcasm and mixed opinions;
English only. Data: UCI Student Performance (maths subset), MNIST subset, authored demo comments –
see `source_notices/`.
