"""Train everything ONCE (locally or in Colab). Creates models/ and reports/.

    python train_all.py              # all models
    python train_all.py --skip-cnn   # if TensorFlow is not installed

Needs data/images.npz for the CNN (keep that file out of GitHub).
"""
import argparse
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
from sklearn.metrics import (ConfusionMatrixDisplay, accuracy_score,
                             confusion_matrix, f1_score)

from src import clustering, data_loader as dl, image_model, nlp, tabular
from src.config import MODELS, REPORTS


def charts(train, target):
    fig, ax = plt.subplots(1, 3, figsize=(15, 4))
    train[target].value_counts().sort_index().plot(kind="bar", ax=ax[0], color=["#4C78A8", "#F58518"])
    ax[0].set(title="Support label counts (train)", xlabel="needs_support (0 = no, 1 = yes)",
              ylabel="Number of records")
    ax[1].hist(train["G2"], bins=range(0, 22, 2), color="#54A24B", edgecolor="white")
    ax[1].set(title="Histogram of G2 (train)", xlabel="G2 (0-20)", ylabel="Number of records")
    train.groupby("studytime")["G2"].mean().plot(kind="bar", ax=ax[2], color="#B279A2")
    ax[2].set(title="Average G2 by studytime (train)", xlabel="studytime", ylabel="Average G2")
    plt.tight_layout(); plt.savefig(REPORTS / "01_data_charts.png", dpi=150); plt.close()


def main(skip_cnn: bool):
    main_df, meta = dl.load_main(), dl.load_meta()
    num, cat, features, target, cluster_features = dl.feature_lists(meta)
    train, val, test = dl.get_splits(main_df)
    print(main_df.groupby("split").size())
    charts(train, target)
    versions = {"scikit-learn": sklearn.__version__, "pandas": pd.__version__, "numpy": np.__version__}

    # --- 1. decision tree + baseline (fit on train, check val, test ONCE) ---
    model, baseline = tabular.train(train, features, target, cat)
    v = [tabular.evaluate("Decision tree (validation)", model, val, features, target)[0],
         tabular.evaluate("Baseline (validation)", baseline, val, features, target)[0]]
    t_tree, pred = tabular.evaluate("Decision tree (test)", model, test, features, target)
    t_base, bpred = tabular.evaluate("Baseline (test)", baseline, test, features, target)
    results = pd.DataFrame([t_tree, t_base]).round(3)
    print(pd.DataFrame(v).round(3), "\n", results)
    results.to_csv(REPORTS / "tabular_test_metrics.csv", index=False)
    (REPORTS / "tabular_test_metrics.json").write_text(json.dumps(
        {"test_class_counts": {str(k): int(c) for k, c in test[target].value_counts().sort_index().items()},
         "validation": pd.DataFrame(v).round(3).to_dict(orient="records"),
         "results": results.to_dict(orient="records")}, indent=2))
    errors = test.assign(predicted=pred)
    errors = errors[errors["predicted"] != errors[target]]
    keep = [c for c in ["record_id"] + features + [target, "predicted"] if c in errors]
    errors[keep].head(5).to_csv(REPORTS / "tabular_five_errors.csv", index=False)

    fig, ax = plt.subplots(1, 2, figsize=(9, 4))
    for a, p, name in ((ax[0], pred, "Decision tree"), (ax[1], bpred, "Baseline")):
        ConfusionMatrixDisplay(confusion_matrix(test[target], p, labels=[0, 1])).plot(ax=a, colorbar=False)
        a.set_title(f"{name} (test)")
    plt.tight_layout(); plt.savefig(REPORTS / "02_tabular_confusion.png", dpi=150); plt.close()

    # --- 2. KMeans (train rows only) ---
    _, summary = clustering.train(train, cluster_features)
    summary.to_csv(REPORTS / "cluster_profiles.csv")
    print(summary)

    # --- 3. CNN ---
    if not skip_cnn:
        if not dl.has_images():
            print("data/images.npz not found - skipping CNN.")
        else:
            import tensorflow as tf
            versions["tensorflow"] = tf.__version__
            images = dl.load_images()
            cnn, hist = image_model.train(images, epochs=3)
            h = hist.history
            fig, ax = plt.subplots(1, 2, figsize=(10, 4))
            for a, k in zip(ax, ("accuracy", "loss")):
                a.plot(h[k], marker="o", label="train"); a.plot(h[f"val_{k}"], marker="o", label="validation")
                a.set(title=k.title(), xlabel="epoch"); a.legend()
            plt.tight_layout(); plt.savefig(REPORTS / "04_cnn_curves.png", dpi=150); plt.close()

            y_pred = cnn.predict(images["x_test"], verbose=0).argmax(axis=1)
            y_true = images["y_test"]
            m = {"accuracy": float(accuracy_score(y_true, y_pred)),
                 "macro_f1": float(f1_score(y_true, y_pred, average="macro")),
                 "epochs_run": len(h["loss"])}
            (REPORTS / "cnn_test_metrics.json").write_text(json.dumps(m, indent=2))
            fig, ax = plt.subplots(figsize=(6, 6))
            ConfusionMatrixDisplay(confusion_matrix(y_true, y_pred, labels=list(range(10))),
                                   display_labels=meta.get("image_classes")).plot(ax=ax, colorbar=False)
            plt.savefig(REPORTS / "05_cnn_confusion.png", dpi=150); plt.close()
            print("CNN:", m)

    # --- 4. NLP check against supplied labels ---
    fb = nlp.analyse(dl.load_feedback())
    print("Sentiment accuracy vs reference:",
          round(accuracy_score(fb["sentiment_label"], fb["predicted_sentiment"]), 3))
    fb.to_csv(REPORTS / "feedback_analysed.csv", index=False)

    # versions used for training -> match these in requirements.txt
    (MODELS / "training_versions.json").write_text(json.dumps(versions, indent=2))
    (MODELS / "feature_metadata.json").write_text(json.dumps(
        {"features": features, "categorical": cat, "numeric": num, "target": target,
         "cluster_features": cluster_features,
         "image_shape": [28, 28, 1], "image_classes": meta.get("image_classes")}, indent=2))
    print("Versions:", versions)
    print("Done. Models saved in models/, reports in reports/.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-cnn", action="store_true")
    main(ap.parse_args().skip_cnn)
