# data/

Copy the supplied files from the dataset pack (`Project_01/data/`) here, unchanged:

- `main.csv` – 395 records with fixed splits (276 train / 59 validation / 60 test)
- `feedback.csv` – 30 authored English comments with reference sentiment labels
- `meta.json` – feature names, allowed values, target, class order
- `topic_keywords.json` – topic rules
- `example_inputs.csv` – five ready form records for the demo
- `prompt_test_cases.json` – five prompt comparison cases
- `image_manifest.csv` – list of the sample images
- `images.npz` – **training only, do NOT upload to GitHub** (it is in `.gitignore`)
